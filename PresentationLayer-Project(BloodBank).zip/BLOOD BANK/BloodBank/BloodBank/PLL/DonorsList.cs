﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BloodBank.PLL
{
    public partial class DonorsList : Form
    {
        public DonorsList()
        {
            InitializeComponent();
        }

        private void donorlist_Click(object sender, EventArgs e)
        {


            showdata();
        }

        public void showdata()
        {
            
        }

        private void DonorsList_Load(object sender, EventArgs e)
        {
            

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }
    }
}     
