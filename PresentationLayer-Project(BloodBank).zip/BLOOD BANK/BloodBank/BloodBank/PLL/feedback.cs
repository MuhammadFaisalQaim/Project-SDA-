﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BloodBank.PLL

{
    public partial class feedback : Form
    {
        public feedback()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }

        private void submit_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text == "")
            {
                MessageBox.Show("Write your Feedback before Submit");
            }
            else
            {


                MessageBox.Show("YOUR FEEDBACK HAS BEEN ADDED SUCCESSFULLY..");

            }
        }
         

        private void feedback_Load(object sender, EventArgs e)
        {

        }
    }
}
