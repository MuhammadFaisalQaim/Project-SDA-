﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BloodBank.PLL
{
    public partial class Search_Donors : Form
    {
        public Search_Donors()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }

        private void profile1_Click(object sender, EventArgs e)
        {
            if (textboxUser.Text == "" && textboxPassword.Text == "")
            {
                MessageBox.Show("Please Fill Both Fields");
                //MessageBox.Show("LOGIN SUCCESSFUL");
                DonorsList p = new DonorsList();
                this.Hide();
                p.Show();

            }
            else
            {
                MessageBox.Show("INVALID SEARCH");
            }
        }
            
        private void Search_Donors_Load(object sender, EventArgs e)
        {

        }
    }
}
